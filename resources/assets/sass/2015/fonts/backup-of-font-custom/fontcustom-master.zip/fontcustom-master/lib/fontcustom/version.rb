module Fontcustom
  VERSION = "1.3.8"
end
